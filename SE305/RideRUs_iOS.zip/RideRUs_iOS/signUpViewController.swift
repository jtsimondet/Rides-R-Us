//
//  signUpViewController.swift
//  RideRUs_iOS
//
//  Created by Rezvi Ahmed on 12/2/17.
//  Copyright © 2017 NewBee. All rights reserved.
//

import UIKit

class signUpViewController: UIViewController {
    
    var signUpMode = true
    
    @IBOutlet var emailTextField: UITextField!
    
    @IBOutlet var passwordTextField: UITextField!
    
    @IBOutlet var signUpOrLogin: UIButton!
    
    
    @IBAction func signUpOrLogin(_ sender: Any) {
        
    
}
    
    @IBAction func changeSignUpMode(_ sender: Any) {
        
        if signUpMode {
            //change to login mode
            signUpOrLogin.setTitle("Log In", for: [])
            changeSignUpModeButton.setTitle("Sign Up", for: [])
            messageLabel.text = "Don't have an account?"
            signUpMode = false
        }
        else{
            signUpOrLogin.setTitle("Sign Up", for: [])
            changeSignUpModeButton.setTitle("Log In", for: [])
            messageLabel.text = "Already have an account?"
            signUpMode = true
        }
        
    }
    
    
    @IBOutlet var changeSignUpModeButton: UIButton!
    @IBOutlet var messageLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
